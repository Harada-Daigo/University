public interface Relatable{
    public boolean isSmallerThan(Relatable other);
}