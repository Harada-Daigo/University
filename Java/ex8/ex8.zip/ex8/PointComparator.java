public interface PointComparator{
    int compare(Point p1, Point p2);
}