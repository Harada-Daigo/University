class test{
    public static void main(String args[]){
        int a = 4;
        int b = 0;
        a = b;
        b = 3;
        System.out.println(a+","+b);
    }
}