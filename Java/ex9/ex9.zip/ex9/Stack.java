public interface Stack{
    void push(int x);
    int pop();
    int top();
    int size();
    boolean empty();
}