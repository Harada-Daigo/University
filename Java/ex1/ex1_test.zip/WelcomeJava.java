class WelcomeJava{
public static void main(String[] args){
}
}