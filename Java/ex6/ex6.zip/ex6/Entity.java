abstract class Entity{
    public String name;
    public String getName(){ return this. name; }
    public void rename(String name){this.name = name}
}