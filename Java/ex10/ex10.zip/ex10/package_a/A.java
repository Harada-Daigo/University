package package_a;
public class A{
    public void print(){
        System.out.println("This is A.");
    }
}